import React from 'react';
import ForgotPassword from '../Components/ForgotPassword/ForgotPassword';

export default class Routes extends React.Component{
	 render(){
        return(
            <>
            	<ForgotPassword />
            </>
        );
    }
}