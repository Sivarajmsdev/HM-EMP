import React from 'react';

export default class Routes extends React.Component{
	 render(){
        return(
            <>
            	<h1>Forgot Password</h1>
            </>
        );
    }
}